'use client';

import React, { useState, Suspense } from 'react';
import { services } from '@/lib/services';
import { serviceFlows } from '@/lib/service-flows';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Copy, Search } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useApiKeys } from '@/context/api-keys-context';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '../ui/textarea';

const VirusTotalResultViewer = React.lazy(() => import('./virustotal-result-viewer'));
const AbuseIPDBResultViewer = React.lazy(() => import('./abuseipdb-result-viewer'));
const GreyNoiseResultViewer = React.lazy(() => import('./greynoise-result-viewer'));
const AlienVaultResultViewer = React.lazy(() => import('./alienvault-result-viewer'));
const IPQualityScoreResultViewer = React.lazy(() => import('./ipqualityscore-result-viewer'));


const resultViewers: Record<string, React.ComponentType<{ result: any }>> = {
    virustotal: VirusTotalResultViewer,
    abuseipdb: AbuseIPDBResultViewer,
    greynoise: GreyNoiseResultViewer,
    alienvault: AlienVaultResultViewer,
    ipqualityscore: IPQualityScoreResultViewer,
};

const serviceCategories = {
    "Reputation & Risk Scoring": ['virustotal', 'abuseipdb', 'ipqualityscore', 'spamhaus', 'ciscotalos'],
    "Threat & OSINT Analysis": ['alienvault', 'xforce', 'greynoise', 'threatminer', 'apivoid', 'riskiq'],
    "Network & Infrastructure": ['securitytrails', 'shodan', 'whoisxml', 'neutrino', 'fraudguard', 'zscaler'],
}

export function ApiRequester() {
  const [inputValues, setInputValues] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState<Record<string, boolean>>({});
  const [results, setResults] = useState<Record<string, any>>({});
  const { toast } = useToast();
  const { apiKeys, incrementLookupCount, addToHistory } = useApiKeys();

  const handleInputChange = (serviceId: string, value: string) => {
    setInputValues((prev) => ({ ...prev, [serviceId]: value }));
  };

  const handleCopyJson = (json: any) => {
    navigator.clipboard.writeText(JSON.stringify(json, null, 2));
    toast({
      title: 'Copied to Clipboard',
      description: 'The JSON response has been copied.',
    });
  };

  const handleSubmit = async (serviceId: string) => {
    const service = services.find(s => s.id === serviceId);
    if (!service) return;

    const inputValue = inputValues[serviceId];
    if (!inputValue) {
      toast({
        variant: 'destructive',
        title: 'Input Required',
        description: 'Please enter a value to search.',
      });
      return;
    }

    const flow = serviceFlows[serviceId];
    if (!flow) {
      toast({
        variant: 'destructive',
        title: 'Service Not Implemented',
        description: `The service "${serviceId}" is not connected to a live API yet.`,
      });
      return;
    }
    
    // Services that don't require an API key
    const keylessServices = ['ciscotalos', 'threatminer'];
    const apiKey = apiKeys[serviceId];
    if (!apiKey && !keylessServices.includes(service.id)) {
      toast({
        variant: 'destructive',
        title: 'API Key Required',
        description: `Please configure the API key for ${service.name} in settings.`,
      });
      return;
    }


    setLoading((prev) => ({ ...prev, [serviceId]: true }));
    setResults((prev) => ({ ...prev, [serviceId]: null }));
    

    let result;
    try {
      let serviceInput;
      const inputPayload = { apiKeys };

      if (service.inputType === 'ipAddress') {
        serviceInput = { ...inputPayload, ipAddress: inputValue };
      } else if (service.inputType === 'query') {
        serviceInput = { ...inputPayload, query: inputValue };
      } else {
        serviceInput = { ...inputPayload, resource: inputValue };
      }

      result = await flow(serviceInput);
      setResults((prev) => ({
        ...prev,
        [serviceId]: result,
      }));
      incrementLookupCount();
      addToHistory({ service: service.name, target: inputValue, status: 'Success', response: result });
    } catch (error: any) {
      console.error(`Error fetching from ${serviceId}:`, error);
      const errorResult = { error: error.message };
      toast({
        variant: 'destructive',
        title: 'API Error',
        description: error.message || `Could not fetch data from ${service.name}.`,
      });
      setResults((prev) => ({
        ...prev,
        [serviceId]: errorResult,
      }));
      incrementLookupCount();
      addToHistory({ service: service.name, target: inputValue, status: 'Failed', response: errorResult });
    } finally {
      setLoading((prev) => ({ ...prev, [serviceId]: false }));
    }
  };
  
  const loadingSkeleton = (
    <div className="space-y-2 pt-2">
      <Skeleton className="h-4 w-full" />
      <Skeleton className="h-4 w-5/6" />
      <Skeleton className="h-4 w-full" />
      <Skeleton className="h-4 w-4/6" />
    </div>
  )

  return (
    <Tabs defaultValue={services[0].id} className="w-full">
      <div className="space-y-4">
        {Object.entries(serviceCategories).map(([category, serviceIds]) => (
            <div key={category}>
                <p className="text-sm text-muted-foreground font-semibold mb-2 px-1">{category}</p>
                <TabsList className="grid h-auto w-full grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-10">
                    {serviceIds.map(id => services.find(s => s.id === id)).filter((s): s is NonNullable<typeof s> => !!s).map((service) => (
                      <TabsTrigger key={service.id} value={service.id} className="flex-col h-14 gap-2">
                         <service.icon className="h-6 w-6" />
                         <span className="text-xs">{service.name}</span>
                      </TabsTrigger>
                    ))}
                </TabsList>
            </div>
        ))}
      </div>
      {services.map((service) => (
        <TabsContent key={service.id} value={service.id}>
           <Card className="mt-4">
            <CardHeader>
                <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-3">
                        <service.icon className="h-6 w-6 text-muted-foreground" />
                        {service.name}
                    </CardTitle>
                    {results[service.id] && (
                         <Button variant="outline" size="sm" onClick={() => handleCopyJson(results[service.id])}>
                            <Copy className="mr-2 h-4 w-4" />
                            Copy JSON
                        </Button>
                    )}
                </div>
                <CardDescription>{service.description}</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="space-y-4">
                <form
                    className="flex w-full items-center space-x-2"
                    onSubmit={(e) => {
                    e.preventDefault();
                    handleSubmit(service.id);
                    }}
                >
                    <div className="relative flex-grow">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                        placeholder={service.placeholder}
                        className="pl-10 h-11"
                        value={inputValues[service.id] || ''}
                        onChange={(e) => handleInputChange(service.id, e.target.value)}
                    />
                    </div>
                    <Button type="submit" disabled={loading[service.id]} size="lg">
                    {loading[service.id] ? 'Fetching...' : 'Fetch'}
                    </Button>
                </form>
                {loading[service.id] && loadingSkeleton}
                {results[service.id] && (
                    <Suspense fallback={loadingSkeleton}>
                      {(() => {
                          const Viewer = resultViewers[service.id];
                          if (Viewer) {
                              return <Viewer result={results[service.id]} />;
                          }
                          return (
                             <Textarea
                                readOnly
                                value={JSON.stringify(results[service.id], null, 2)}
                                className="h-64 font-code text-xs bg-muted/50 mt-4"
                              />
                          );
                      })()}
                    </Suspense>
                )}
                </div>
            </CardContent>
            </Card>
        </TabsContent>
      ))}
    </Tabs>
  );
}
