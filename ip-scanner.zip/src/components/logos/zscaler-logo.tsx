import type { FC, SVGProps } from 'react';

export const ZscalerLogo: FC<SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    width="1em"
    height="1em"
    fill="#0099d8"
    {...props}
  >
    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1.05 13.95L12 14.9l1.05 1.05 2.8-2.8-1.05-1.05-1.75 1.75-1.75-1.75-1.05 1.05 2.8 2.8zm-2.8-4.2L12 8.7l1.05 1.05 2.8-2.8-1.05-1.05-1.75 1.75-1.75-1.75-1.05 1.05 2.8 2.8z" />
  </svg>
);
