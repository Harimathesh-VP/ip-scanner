import { LoginForm } from '@/components/auth/login-form';
import { ZeroSharkLogo } from '@/components/logos/zeroshark-logo';
import Link from 'next/link';

export default function LoginPage() {
  return (
    <div className="w-full lg:grid lg:min-h-screen lg:grid-cols-2">
      <div className="hidden bg-muted lg:flex lg:flex-col lg:items-center lg:justify-center p-8">
         <div className="flex flex-col items-center text-center">
            <Link href="/" className="flex items-center gap-3 mb-6" prefetch={false}>
              <ZeroSharkLogo className="h-12 w-12 text-primary" />
            </Link>
             <h1 className="text-4xl font-bold font-headline text-primary">ZeroShark</h1>
            <p className="text-lg text-muted-foreground mt-2 max-w-sm">
                Your central hub for querying top-tier security APIs.
            </p>
         </div>
      </div>
       <div className="flex items-center justify-center py-12 px-4">
            <div className="w-full max-w-sm">
                <div className="lg:hidden mb-8 text-center">
                     <Link href="/" className="flex items-center justify-center gap-2 font-semibold" prefetch={false}>
                        <ZeroSharkLogo className="h-8 w-8 text-primary" />
                        <span className="text-2xl font-bold font-headline text-primary">ZeroShark</span>
                    </Link>
                </div>
                <LoginForm />
            </div>
      </div>
    </div>
  );
}
