'use server';

/**
 * @fileOverview A function for interacting with the Cisco Talos reputation API.
 * - callCiscoTalos - A function that takes a resource and returns Talos data.
 */

import { z } from 'zod';

const CiscoTalosInputSchema = z.object({
  resource: z.string().describe('The IP or domain to query.'),
  // Cisco Talos doesn't require an API key for its public reputation lookup.
  apiKeys: z.record(z.string()).optional(),
});
export type CiscoTalosInput = z.infer<typeof CiscoTalosInputSchema>;

export type CiscoTalosOutput = any;

export async function callCiscoTalos(input: CiscoTalosInput): Promise<CiscoTalosOutput> {
    const { resource } = input;
  
    // The public endpoint is proxied through a service to avoid CORS issues
    // and to parse the HTML response into JSON.
    const endpoint = `https://talos.intelligence.exposed/api/v1/details/${resource}`;

    try {
        const response = await fetch(endpoint, {
          headers: {
            'Accept': 'application/json'
          }
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || `Cisco Talos lookup failed with status: ${response.status}`);
        }
        
        return await response.json();
    } catch (err: any) {
        console.error('Error calling Cisco Talos lookup:', err.message);
        throw new Error(err.message || 'Failed to fetch data from Cisco Talos.');
    }
}
