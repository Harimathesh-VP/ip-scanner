'use server';

/**
 * @fileOverview A function for interacting with the RiskIQ PassiveTotal API.
 * - callRiskIQ - A function that takes a resource and returns PassiveTotal data.
 */

import { z } from 'zod';

const RiskIQInputSchema = z.object({
  resource: z.string().describe('The IP, domain, or ASN to check.'),
  apiKeys: z.record(z.string()).optional().describe('The RiskIQ API user and key, colon-separated.'),
});
export type RiskIQInput = z.infer<typeof RiskIQInputSchema>;

export type RiskIQOutput = any;

export async function callRiskIQ(input: RiskIQInput): Promise<RiskIQOutput> {
  const { resource, apiKeys } = input;
  const apiKeyString = apiKeys?.riskiq || process.env.RISKIQ_API_KEY;

  if (!apiKeyString || !apiKeyString.includes(':')) {
    throw new Error('RISKIQ_API_KEY is not provided or configured. It must be in the format `email:key`.');
  }

  const [user, key] = apiKeyString.split(':');
  
  const credentials = Buffer.from(`${user}:${key}`).toString('base64');
  const endpoint = `https://api.riskiq.net/pt/v2/enrichment`;

  try {
    const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
            'Authorization': `Basic ${credentials}`,
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ query: resource }),
    });

    if (!response.ok) {
        if (response.status === 404) {
            return { error: 'Not Found', message: `Resource '${resource}' not found in RiskIQ.`};
        }
        if (response.status === 401) {
            throw new Error('RiskIQ API error: Authentication failed. Check your API key.');
        }
        const errorText = await response.text();
        throw new Error(`RiskIQ API error! status: ${response.status} - ${errorText}`);
    }

    const data = await response.json();
    
    // The main data is nested, let's lift it up for easier consumption.
    const result: Record<string, any> = {};
    if (data.passivedns) result.passive_dns = data.passivedns;
    if (data.whois) result.whois = data.whois;
    if (data.resolutions) result.resolutions = data.resolutions;
    if (data.subdomains) result.subdomains = data.subdomains;
    if (data.certificates) result.certificates = data.certificates;
    if (data.reputation) result.reputation = data.reputation;

    return result;

  } catch (err: any) {
      console.error('Error calling RiskIQ API:', err.message);
      throw new Error(err.message || 'Failed to fetch data from RiskIQ.');
  }
}
