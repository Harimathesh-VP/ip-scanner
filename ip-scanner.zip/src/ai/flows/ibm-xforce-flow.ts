'use server';

/**
 * @fileOverview A function for interacting with the IBM X-Force Exchange API.
 * - callIBMForce - A function that takes a resource and returns X-Force data.
 */

import { z } from 'zod';

const IBMXForceInputSchema = z.object({
  resource: z.string().describe('The IP, URL, or hash to query.'),
  apiKeys: z.record(z.string()).optional().describe('The IBM X-Force API key and password, colon-separated.'),
});
export type IBMXForceInput = z.infer<typeof IBMXForceInputSchema>;

export type IBMXForceOutput = any;

export async function callIBMForce(input: IBMXForceInput): Promise<IBMXForceOutput> {
  const { resource, apiKeys } = input;
  const apiKeyString = apiKeys?.xforce || process.env.XFORCE_API_KEY;
  
  if (!apiKeyString) {
    throw new Error('XFORCE_API_KEY is not provided or configured. It should be in the format `key:password`.');
  }

  // The API key is a combination of key and password, base64 encoded.
  const credentials = Buffer.from(apiKeyString).toString('base64');
  
  let endpoint;
  // Basic check for IP address
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(resource)) {
    endpoint = `https://api.xforce.ibmcloud.com/ipr/${resource}`;
  } 
  // Basic check for URL (handle potential protocol)
  else if (resource.startsWith('http') || /^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(resource)) {
     endpoint = `https://api.xforce.ibmcloud.com/url/${resource}`;
  }
  // Assume hash if not IP or URL-like
  else {
    endpoint = `https://api.xforce.ibmcloud.com/malware/${resource}`;
  }

  try {
    const response = await fetch(endpoint, {
      headers: { 
        'Authorization': `Basic ${credentials}`,
        'Accept': 'application/json' 
      },
    });

    if (!response.ok) {
      if (response.status === 404) {
        return { error: 'Not Found', message: `Resource '${resource}' not found in IBM X-Force.`};
      }
      if (response.status === 401) {
        throw new Error('IBM X-Force API error: Authentication failed. Please check your API key and password.');
      }
      const errorText = await response.text();
      throw new Error(`IBM X-Force API error! status: ${response.status} - ${errorText}`);
    }
    
    // Handle empty response body
    if (response.headers.get('content-length') === '0') {
      return { info: `Resource '${resource}' found, but no detailed content returned from IBM X-Force.`};
    }
    
    const data = await response.json();
    return data;
    
  } catch (err: any) {
    console.error('Error calling IBM X-Force API:', err.message);
    throw new Error(err.message || 'Failed to fetch data from IBM X-Force.');
  }
}
