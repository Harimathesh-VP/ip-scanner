'use server';

/**
 * @fileOverview A function for interacting with the ThreatMiner API.
 * - callThreatMiner - A function that takes a resource and returns ThreatMiner data.
 */

import { z } from 'zod';

const ThreatMinerInputSchema = z.object({
  resource: z.string().describe('The IP, domain, or hash to check.'),
  apiKeys: z.record(z.string()).optional(), // ThreatMiner doesn't require a key
});
export type ThreatMinerInput = z.infer<typeof ThreatMinerInputSchema>;

export type ThreatMinerOutput = any;

export async function callThreatMiner(input: ThreatMinerInput): Promise<ThreatMinerOutput> {
  const { resource } = input;
  
  let queryType;
  const isIp = /^\d{1,3}(\.\d{1,3}){3}$/.test(resource);
  const isDomain = /^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(resource);
  
  if (isIp) {
      queryType = 'ip';
  } else if (isDomain) {
      queryType = 'domain';
  } else {
      queryType = 'sample'; // for hashes
  }

  // ThreatMiner has different endpoints for different report types (rt).
  // 1 = WHOIS, 2 = Passive DNS, 3 = Example query, 4 = URLs, 5 = Hashes
  const reportTypes = [1, 2, 4, 5];
  const results: Record<string, any> = { indicator: resource };

  try {
    for (const rt of reportTypes) {
      const endpoint = `https://api.threatminer.org/v2/${queryType}.php?q=${resource}&rt=${rt}`;
      const response = await fetch(endpoint);
      
      if (response.ok) {
        const data = await response.json();
        if (data.status_code === '200' && data.results) {
            switch(rt) {
                case 1: results.whois = data.results; break;
                case 2: results.passive_dns = data.results; break;
                case 4: results.urls = data.results; break;
                case 5: results.hashes = data.results; break;
            }
        }
      } else {
         console.warn(`ThreatMiner request failed for rt=${rt} with status: ${response.status}`);
      }
    }
    
    if(Object.keys(results).length === 1) { // Only contains the indicator
      return { error: 'Not Found', message: `No data found for '${resource}' on ThreatMiner.`};
    }

    return results;

  } catch (err: any) {
    console.error('Error calling ThreatMiner API:', err.message);
    throw new Error('Failed to fetch data from ThreatMiner.');
  }
}
