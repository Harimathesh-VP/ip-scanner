'use server';

/**
 * @fileOverview A function for interacting with the APIVoid API.
 * - callAPIVoid - A function that takes a resource and returns APIVoid analysis.
 */

import { z } from 'zod';

const APIVoidInputSchema = z.object({
  resource: z.string().describe('The IP, domain, or URL to check.'),
  apiKeys: z.record(z.string()).optional().describe('The APIVoid API key.'),
});
export type APIVoidInput = z.infer<typeof APIVoidInputSchema>;

export type APIVoidOutput = any;

export async function callAPIVoid(input: APIVoidInput): Promise<APIVoidOutput> {
  const { resource, apiKeys } = input;
  const apiKey = apiKeys?.apivoid || process.env.APIVOID_API_KEY;

  if (!apiKey) {
    throw new Error('APIVOID_API_KEY is not provided or configured.');
  }
  
  const isIp = /^\d{1,3}(\.\d{1,3}){3}$/.test(resource);
  const isDomain = /^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(resource);
  
  let endpoint;
  if(isIp) {
      endpoint = `https://endpoint.apivoid.com/iprep/v1/pay-as-you-go/?key=${apiKey}&ip=${resource}`;
  } else if (isDomain) {
      endpoint = `https://endpoint.apivoid.com/domainbl/v1/pay-as-you-go/?key=${apiKey}&host=${resource}`;
  } else {
      endpoint = `https://endpoint.apivoid.com/urlrep/v1/pay-as-you-go/?key=${apiKey}&url=${encodeURIComponent(resource)}`;
  }


  try {
    const response = await fetch(endpoint);
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || `APIVoid API error! status: ${response.status}`);
    }
    return await response.json();
  } catch (err: any) {
    console.error('Error calling APIVoid API:', err.message);
    throw new Error(err.message || 'Failed to fetch data from APIVoid.');
  }
}
