'use server';

/**
 * @fileOverview A function for interacting with the VirusTotal API.
 * - callVirusTotal - A function that takes a resource (domain, IP, URL) and returns VirusTotal analysis.
 */
import { z } from 'zod';

const VirusTotalInputSchema = z.object({
  resource: z.string().describe('The domain, IP address, or URL to query.'),
  apiKeys: z.record(z.string()).optional().describe('The VirusTotal API key.'),
});
export type VirusTotalInput = z.infer<typeof VirusTotalInputSchema>;

export type VirusTotalOutput = any;

export async function callVirusTotal(input: VirusTotalInput): Promise<VirusTotalOutput> {
  const { resource, apiKeys } = input;
  const key = apiKeys?.virustotal || process.env.VIRUSTOTAL_API_KEY;
  if (!key) {
    throw new Error('VIRUSTOTAL_API_KEY is not provided or configured.');
  }

  let url;
  let resourceType;
  try {
    // Basic check for IP address
    if (/^\d{1,3}(\.\d{1,3}){3}$/.test(resource)) {
      url = `https://www.virustotal.com/api/v3/ip_addresses/${resource}`;
      resourceType = 'ip_address';
    }
    // Basic check for domain
    else if (/^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(resource)) {
      url = `https://www.virustotal.com/api/v3/domains/${resource}`;
      resourceType = 'domain';
    }
    // Assume URL otherwise
    else {
       // VirusTotal requires URL to be base64 encoded without padding
       const encodedUrl = Buffer.from(resource).toString('base64').replace(/=/g, '');
       url = `https://www.virustotal.com/api/v3/urls/${encodedUrl}`;
       resourceType = 'url';
    }

    // A map to store all fetch promises
    const promises: Record<string, Promise<Response>> = {
      main: fetch(url, { headers: { 'x-apikey': key } }),
    };

    // For IPs and domains, add related data fetches
    if (resourceType === 'ip_address') {
        promises.resolutions = fetch(`${url}/resolutions`, { headers: { 'x-apikey': key } });
    } else if (resourceType === 'domain') {
        promises.subdomains = fetch(`${url}/subdomains`, { headers: { 'x-apikey': key } });
        promises.whois = fetch(`${url}/whois`, { headers: { 'x-apikey': key } });
    }

    const responses = await Promise.all(Object.values(promises));
    const responseMap: Record<string, Response> = Object.keys(promises).reduce((acc, key, index) => {
        acc[key] = responses[index];
        return acc;
    }, {} as Record<string, Response>);

    // Handle main request failure
    if (!responseMap.main.ok) {
        if(responseMap.main.status === 404) {
            const errorData = await responseMap.main.json();
            return { error: errorData.error.message };
        }
        throw new Error(`VirusTotal API error! status: ${responseMap.main.status}`);
    }
    
    const mainData = await responseMap.main.json();

    // Attach related data if successful
    if (responseMap.resolutions?.ok) {
        mainData.data.attributes.resolutions = (await responseMap.resolutions.json()).data;
    }
    if (responseMap.subdomains?.ok) {
        mainData.data.attributes.subdomains = (await responseMap.subdomains.json()).data;
    }
    if (responseMap.whois?.ok) {
        const whoisData = (await responseMap.whois.json()).data.attributes.whois;
        mainData.data.attributes.whois = whoisData;
    }

    return mainData;

  } catch (err: any) {
    console.error('Error calling VirusTotal API:', err.message);
    throw new Error(err.message || 'Failed to fetch data from VirusTotal.');
  }
}
