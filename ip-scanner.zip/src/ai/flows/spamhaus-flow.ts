'use server';

/**
 * @fileOverview A function for interacting with the Spamhaus API.
 * - callSpamhaus - A function that takes a resource and returns Spamhaus blocklist info.
 */

import { z } from 'zod';

const SpamhausInputSchema = z.object({
  resource: z.string().describe('The IP or domain to check.'),
  apiKeys: z.record(z.string()).optional().describe('The Spamhaus DQS API key.'),
});
export type SpamhausInput = z.infer<typeof SpamhausInputSchema>;

export type SpamhausOutput = any;

export async function callSpamhaus(input: SpamhausInput): Promise<SpamhausOutput> {
  const { resource, apiKeys } = input;
  const apiKey = apiKeys?.spamhaus || process.env.SPAMHAUS_API_KEY;

  if (!apiKey) {
    throw new Error('SPAMHAUS_API_KEY is not provided or configured.');
  }

  let endpoint;
  const isIp = /^\d{1,3}(\.\d{1,3}){3}$/.test(resource);
  
  if (isIp) {
      endpoint = `https://api.spamhaus.com/v2/ip/${resource}`;
  } else {
      endpoint = `https://api.spamhaus.com/v2/host/${resource}`;
  }

  try {
    const response = await fetch(endpoint, {
      headers: {
        'Authorization': `Bearer ${apiKey}`
      }
    });

    if (!response.ok) {
        if (response.status === 404) {
            return { listed: false, blocklists: [], message: `Resource '${resource}' not found in Spamhaus.`};
        }
        if (response.status === 401) {
            throw new Error('Spamhaus API error: Authentication failed. Check your API key.');
        }
        const errorData = await response.json();
        throw new Error(errorData.error?.title || `Spamhaus API error! status: ${response.status}`);
    }

    return await response.json();
  } catch (err: any) {
    console.error('Error calling Spamhaus API:', err.message);
    throw new Error(err.message || 'Failed to fetch data from Spamhaus.');
  }
}
