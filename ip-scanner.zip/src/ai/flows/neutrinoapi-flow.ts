'use server';

/**
 * @fileOverview A function for interacting with the Neutrino API.
 * - callNeutrinoAPI - A function that takes an IP address and returns Neutrino analysis.
 */

import { z } from 'zod';

const NeutrinoAPIInputSchema = z.object({
  ipAddress: z.string().describe('The IP address to check.'),
  apiKeys: z.record(z.string()).optional().describe('The Neutrino API key and user ID, colon-separated.'),
});
export type NeutrinoAPIInput = z.infer<typeof NeutrinoAPIInputSchema>;

export type NeutrinoAPIOutput = any;

export async function callNeutrinoAPI(input: NeutrinoAPIInput): Promise<NeutrinoAPIOutput> {
  const { ipAddress, apiKeys } = input;
  const apiKeyString = apiKeys?.neutrino || process.env.NEUTRINO_API_KEY;

  if (!apiKeyString || !apiKeyString.includes(':')) {
    throw new Error('NEUTRINO_API_KEY is not provided or configured correctly. It must be in the format `user-id:api-key`.');
  }

  const [userId, apiKey] = apiKeyString.split(':');
  
  const endpoint = 'https://neutrinoapi.net/ip-probe';
  
  const params = {
      'ip': ipAddress,
      'output-case': 'snake'
  };

  try {
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'User-ID': userId,
        'API-Key': apiKey,
      },
      body: new URLSearchParams(params),
    });

    if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData['api-error-msg'] || `Neutrino API error! status: ${response.status}`);
    }
    
    return await response.json();
  } catch (err: any) {
    console.error('Error calling Neutrino API:', err.message);
    throw new Error(err.message || 'Failed to fetch data from Neutrino API.');
  }
}
