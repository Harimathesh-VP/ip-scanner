'use server';

/**
 * @fileOverview A function for interacting with the WhoisXML API.
 * - callWhoisXML - A function that takes a resource and returns WHOIS data.
 */

import { z } from 'zod';

const WhoisXMLInputSchema = z.object({
  resource: z.string().describe('The domain, IP, or ASN to check.'),
  apiKeys: z.record(z.string()).optional().describe('The WhoisXML API key.'),
});
export type WhoisXMLInput = z.infer<typeof WhoisXMLInputSchema>;

export type WhoisXMLOutput = any;

export async function callWhoisXML(input: WhoisXMLInput): Promise<WhoisXMLOutput> {
  const { resource, apiKeys } = input;
  const apiKey = apiKeys?.whoisxml || process.env.WHOISXML_API_KEY;

  if (!apiKey) {
    throw new Error('WHOISXML_API_KEY is not provided or configured.');
  }
  
  const endpoint = `https://www.whoisxmlapi.com/whoisserver/WhoisService?apiKey=${apiKey}&domainName=${resource}&outputFormat=JSON`;

  try {
    const response = await fetch(endpoint);
    if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.ErrorMessage?.msg || `WhoisXML API error! status: ${response.status}`);
    }
    const data = await response.json();
    if(data.ErrorMessage) {
       throw new Error(data.ErrorMessage.msg);
    }
    return data;
  } catch (err: any) {
    console.error('Error calling WhoisXML API:', err.message);
    throw new Error(err.message || 'Failed to fetch data from WhoisXML API.');
  }
}
