'use server';
import { config } from 'dotenv';
config();
